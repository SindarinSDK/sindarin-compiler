from pathlib import Path
import json,re,gzip,hashlib
root=Path.cwd();folder=root/'.sn/record-ref-goal';compiler=root/'bin/sn';digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
counts={}
for file,total in [('method-full-C.log',3244),('method-full-Rust.log',1099)]:
 s=re.sub(r'\x1b\[[0-9;]*m','',(folder/file).read_text());rows=re.findall(r'Results: (\d+) passed, (\d+) failed(?:, (\d+) skipped)?',s);assert sum(int(row[0]) for row in rows)==total and all(int(r[1])==0 and (not r[2] or int(r[2])==0) for r in rows),(file,rows);counts[file]=total
for file,count in [('reference-record-compounds.json',144),('reference-record-compounds-sanitized.json',144),('package-reference-record-compounds.json',36),('package-reference-record-compounds-sanitized.json',36)]:
 d=json.loads((root/'.sn'/file).read_text());assert d['passed'] and len(d['cases'])==count and d['compiler_sha256']==digest(compiler);counts[file]=count
ref=json.loads(gzip.decompress((root/'docs/rust-parity-evidence/math-source-preservation-local.json.gz').read_bytes()));d={'compiler_sha256':digest(compiler),'compiler_source_sha256':ref['compiler_source_sha256']}
for rel,h in d['compiler_source_sha256'].items():assert digest(root/rel)==h,rel
sdk=Path('../sindarin-sdk-tls-artifacts/.sn/sdk-native-integration');old=json.loads((folder/'source-preservation.json').read_text())
for key,val in old.items():
 if isinstance(val,dict) and len(val)==87:
  for rel,h in val.items():assert digest(sdk/rel)==h,rel
  d[key]=val
assert any(isinstance(v,dict) and len(v)==87 for v in d.values())
d['all_sources_and_oracles_unchanged']=True;(folder/'method-source-preservation.json').write_text(json.dumps(d,indent=2)+'\n');print(counts)
