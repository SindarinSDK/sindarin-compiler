import concurrent.futures,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/zlib-goal';compiler=root/'bin/sn';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
san={'SN_CC':'gcc','SN_CFLAGS':'-fsanitize=address,undefined -fno-omit-frame-pointer','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
report={'compiler_sha256':sha(compiler),'isolated_compiler_sha256':sha(folder/'loan-compiler/sn'),'checks':[],'started':time.time(),'completed_reused_checks':[]};assert report['compiler_sha256']==report['isolated_compiler_sha256']
for name,count in [('sdk-zlib-artifact-sanitized',108),('c-array-call-arguments',18),('c-array-call-arguments-sanitized',18)]:
 p=root/'.sn'/(name+'.json');d=json.loads(p.read_text());assert d['passed'] and len(d['cases'])==count and d['compiler_sha256']==report['compiler_sha256'];report['completed_reused_checks'].append({'report':str(p.relative_to(root)),'cases':count,'sha256':sha(p)})
for name in ('C','Rust'):
 p=folder/('final-full-'+name+'.log');assert 'All tests passed!' in p.read_text();report['completed_reused_checks'].append({'log':str(p.relative_to(root)),'sha256':sha(p)})
for name in ('runtime-ABI','runtime-ABI-sanitized'):
 p=folder/(name+'.log');assert 'PASS:' in p.read_text();report['completed_reused_checks'].append({'log':str(p.relative_to(root)),'sha256':sha(p),'scope':'Runtime implementation, staged header/archive and runtime client sources unchanged since these successful executions; later changes are compiler/C projection/templates only.'})
checks=[('memory-normal',['python3','tests/package/borrowed_scalar_memory.py'],{}),('memory-sanitized',['python3','tests/package/borrowed_scalar_memory.py'],san),('zlib-normal',['python3','scripts/check_sdk_zlib_artifact.py'],{}),('imports',['python3','tests/package/native_imports.py'],{}),('artifacts',['python3','tests/package/native_artifacts.py'],{}),('method-normal',['python3','scripts/check_rust_method_struct_parameters.py'],{}),('method-sanitized',['python3','scripts/check_rust_method_struct_parameters.py'],san),('array-normal',['python3','scripts/check_rust_default_array_parameters.py'],{}),('array-sanitized',['python3','scripts/check_rust_default_array_parameters.py'],san),('array-packages-normal',['python3','tests/package/default_array_parameters.py'],{}),('array-packages-sanitized',['python3','tests/package/default_array_parameters.py'],san),('fields-normal',['python3','scripts/check_rust_native_array_fields.py'],{}),('fields-sanitized',['python3','scripts/check_rust_native_array_fields.py'],san),('numeric-owners',['make','-o','build','test-rust-parity-numeric-places'],{}),('strings-normal',['python3','scripts/check_rust_string_call_arguments.py'],{}),('strings-sanitized',['python3','scripts/check_rust_string_call_arguments.py'],san),('helpers',['python3','-m','unittest','discover','-s','tests/ci','-v'],{}),('format',[str(compiler),'--format','--check'],{})]
def run(check):
 name,cmd,env=check;print('START',name,flush=True);start=time.monotonic()
 with (folder/('final-'+name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT)
 print('END',name,p.returncode,flush=True);return {'name':name,'command':cmd,'environment':env,'status':p.returncode,'seconds':time.monotonic()-start}
def retain():
 report['passed']=all(c['status']==0 for c in report['checks']);(folder/'final-composed-validation.json').write_text(json.dumps(report,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,c) for c in checks]):report['checks'].append(f.result());retain()
report['finished']=time.time();report['binary_unchanged']=sha(compiler)==report['compiler_sha256'];retain();assert report['passed'] and report['binary_unchanged']
