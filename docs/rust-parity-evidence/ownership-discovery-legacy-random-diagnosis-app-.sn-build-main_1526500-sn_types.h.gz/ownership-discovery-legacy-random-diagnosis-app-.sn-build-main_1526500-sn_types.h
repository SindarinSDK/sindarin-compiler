#ifndef SN_TYPES_H
#define SN_TYPES_H

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#include "sn_minimal.h"


typedef struct __Closure__ {
    void *fn;
    size_t size;
    void (*__cleanup__)(void *);
    int __rc__;
} __Closure__;
/* Struct: Random (native, as ref — refcounted) */
typedef struct {
    int __rc__;
    int32_t is_seeded;
    long long state;
} __sn__Random;



static inline __sn__Random *__sn__Random__new(void) {
    __sn__Random *p = calloc(1, sizeof(__sn__Random));
    p->__rc__ = 1;
    return p;
}

static inline __sn__Random *__sn__Random_retain(__sn__Random *p) {
    if (p) p->__rc__++;
    return p;
}

static inline void __sn__Random_release(__sn__Random **p) {
    if (*p && --(*p)->__rc__ == 0) {
        free(*p);
    }
    *p = NULL;
}


#define sn_auto_Random __attribute__((cleanup(__sn__Random_release)))
#define sn_auto_ref_Random __attribute__((cleanup(__sn__Random_release)))

static inline void __sn__Random_release_elem(void *p) { __sn__Random_release((__sn__Random **)p); }
static inline void __sn__Random_retain_into(const void *src, void *dst) { *(__sn__Random **)dst = __sn__Random_retain(*(__sn__Random *const *)src); }


void __sn__test_create();
void __sn__test_create_with_seed();
void __sn__test_static_int();
void __sn__test_static_long();
void __sn__test_static_double();
void __sn__test_static_bool();
void __sn__test_static_byte();
void __sn__test_static_bytes();
void __sn__test_static_gaussian();
void __sn__test_static_int_many();
void __sn__test_static_long_many();
void __sn__test_static_double_many();
void __sn__test_static_bool_many();
void __sn__test_static_gaussian_many();
void __sn__test_static_choice_int();
void __sn__test_static_choice_str();
void __sn__test_static_shuffle_int();
void __sn__test_static_shuffle_str();
void __sn__test_static_sample_int();
void __sn__test_static_weighted_choice_int();
void __sn__test_static_weighted_choice_str();
void __sn__test_instance_int();
void __sn__test_instance_long();
void __sn__test_instance_double();
void __sn__test_instance_bool();
void __sn__test_instance_byte();
void __sn__test_instance_bytes();
void __sn__test_instance_gaussian();
void __sn__test_instance_int_many();
void __sn__test_instance_choice_int();
void __sn__test_instance_choice_str();
void __sn__test_instance_shuffle_int();
void __sn__test_instance_sample_int();
void __sn__test_instance_weighted_choice_str();
void __sn__test_seeded_determinism();
void __sn__test_different_seeds();

__sn__Random * __sn__Random_create();
__sn__Random * __sn__Random_createWithSeed(long long);
void __sn__Random_dispose(__sn__Random *);
long long __sn__Random_randInt(long long, long long);
long long __sn__Random_randLong(long long, long long);
double __sn__Random_randDouble(double, double);
bool __sn__Random_randBool();
unsigned char __sn__Random_randByte();
SnArray * __sn__Random_randBytes(long long);
double __sn__Random_randGaussian(double, double);
SnArray * __sn__Random_randIntMany(long long, long long, long long);
SnArray * __sn__Random_randLongMany(long long, long long, long long);
SnArray * __sn__Random_randDoubleMany(double, double, long long);
SnArray * __sn__Random_randBoolMany(long long);
SnArray * __sn__Random_randGaussianMany(double, double, long long);
long long __sn__Random_randChoiceInt(SnArray *);
long long __sn__Random_randChoiceLong(SnArray *);
double __sn__Random_randChoiceDouble(SnArray *);
char * __sn__Random_randChoiceStr(SnArray *);
bool __sn__Random_randChoiceBool(SnArray *);
unsigned char __sn__Random_randChoiceByte(SnArray *);
long long __sn__Random_randWeightedChoiceInt(SnArray *, SnArray *);
long long __sn__Random_randWeightedChoiceLong(SnArray *, SnArray *);
double __sn__Random_randWeightedChoiceDouble(SnArray *, SnArray *);
char * __sn__Random_randWeightedChoiceStr(SnArray *, SnArray *);
void __sn__Random_randShuffleInt(SnArray *);
void __sn__Random_randShuffleLong(SnArray *);
void __sn__Random_randShuffleDouble(SnArray *);
void __sn__Random_randShuffleStr(SnArray *);
void __sn__Random_randShuffleBool(SnArray *);
void __sn__Random_randShuffleByte(SnArray *);
SnArray * __sn__Random_randSampleInt(SnArray *, long long);
SnArray * __sn__Random_randSampleLong(SnArray *, long long);
SnArray * __sn__Random_randSampleDouble(SnArray *, long long);
SnArray * __sn__Random_randSampleStr(SnArray *, long long);
long long __sn__Random_nextInt(__sn__Random *, long long, long long);
long long __sn__Random_nextLong(__sn__Random *, long long, long long);
double __sn__Random_nextDouble(__sn__Random *, double, double);
bool __sn__Random_nextBool(__sn__Random *);
unsigned char __sn__Random_nextByte(__sn__Random *);
SnArray * __sn__Random_nextBytes(__sn__Random *, long long);
double __sn__Random_gaussian(__sn__Random *, double, double);
SnArray * __sn__Random_intMany(__sn__Random *, long long, long long, long long);
SnArray * __sn__Random_longMany(__sn__Random *, long long, long long, long long);
SnArray * __sn__Random_doubleMany(__sn__Random *, double, double, long long);
SnArray * __sn__Random_boolMany(__sn__Random *, long long);
SnArray * __sn__Random_gaussianMany(__sn__Random *, double, double, long long);
long long __sn__Random_choiceInt(__sn__Random *, SnArray *);
long long __sn__Random_choiceLong(__sn__Random *, SnArray *);
double __sn__Random_choiceDouble(__sn__Random *, SnArray *);
char * __sn__Random_choiceStr(__sn__Random *, SnArray *);
bool __sn__Random_choiceBool(__sn__Random *, SnArray *);
unsigned char __sn__Random_choiceByte(__sn__Random *, SnArray *);
long long __sn__Random_weightedChoiceInt(__sn__Random *, SnArray *, SnArray *);
long long __sn__Random_weightedChoiceLong(__sn__Random *, SnArray *, SnArray *);
double __sn__Random_weightedChoiceDouble(__sn__Random *, SnArray *, SnArray *);
char * __sn__Random_weightedChoiceStr(__sn__Random *, SnArray *, SnArray *);
void __sn__Random_shuffleInt(__sn__Random *, SnArray *);
void __sn__Random_shuffleLong(__sn__Random *, SnArray *);
void __sn__Random_shuffleDouble(__sn__Random *, SnArray *);
void __sn__Random_shuffleStr(__sn__Random *, SnArray *);
void __sn__Random_shuffleBool(__sn__Random *, SnArray *);
void __sn__Random_shuffleByte(__sn__Random *, SnArray *);
SnArray * __sn__Random_sampleInt(__sn__Random *, SnArray *, long long);
SnArray * __sn__Random_sampleLong(__sn__Random *, SnArray *, long long);
SnArray * __sn__Random_sampleDouble(__sn__Random *, SnArray *, long long);
SnArray * __sn__Random_sampleStr(__sn__Random *, SnArray *, long long);



#endif
