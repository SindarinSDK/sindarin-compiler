import concurrent.futures,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tcp-artifact-goal';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'compiler_sha256':sha(root/'bin/sn'),'checks':[],'started':time.time()}
checks=json.loads((folder/'composed-checks.json').read_text())
def run(c):
 print('START',c['name'],flush=True);start=time.monotonic()
 with (folder/('composed-'+c['name']+'.log')).open('wb') as log:
  p=subprocess.run(c['command'],cwd=root,env={**os.environ,**c['environment']},stdout=log,stderr=subprocess.STDOUT)
 print('END',c['name'],p.returncode,flush=True)
 return {**c,'status':p.returncode,'seconds':time.monotonic()-start}
def retain():
 report['passed']=all(c['status']==0 for c in report['checks']);(folder/'composed-validation.json').write_text(json.dumps(report,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,c) for c in checks]):report['checks'].append(f.result());retain()
report['finished']=time.time();report['binary_unchanged']=sha(root/'bin/sn')==report['compiler_sha256'];retain();assert report['passed'] and report['binary_unchanged']
