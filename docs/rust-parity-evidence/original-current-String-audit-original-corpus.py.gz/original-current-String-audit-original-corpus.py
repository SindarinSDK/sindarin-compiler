import concurrent.futures,collections,gzip,hashlib,json,os,re,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();compiler=root/'bin/sn';folder=root/'.sn/string-call-owners-goal/original-corpus';folder.mkdir(exist_ok=True)
ref=json.loads(gzip.decompress((root/'docs/rust-parity-evidence/math-source-preservation-local.json.gz').read_bytes()));sources={p:h for p,h in ref['compiler_source_sha256'].items() if p.endswith('.sn')};assert len(sources)==1365
for p,h in ref['compiler_source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'started':time.time(),'target':'rust','mode':'-O0 -g default, unchanged C harness output/panic contracts','source_count':1365,'original_oracle_files':1158,'scope':'Current goal-start original sources and frozen oracles; Linux discovery only, not final all-mode/platform or C-defined semantics acceptance. Programs without output oracles receive execution-only status.','cases':[]}
def call(cmd,timeout,cwd=root,merged=False):
 try:
  p=subprocess.run([str(v) for v in cmd],cwd=cwd,capture_output=not merged,stdout=subprocess.PIPE if merged else None,stderr=subprocess.STDOUT if merged else None,timeout=timeout)
  return {'command':[str(v) for v in cmd],'status':p.returncode,'stdout_hex':(p.stdout or b'').hex(),'stderr_hex':(p.stderr or b'').hex()}
 except subprocess.TimeoutExpired as e:return {'status':'timeout','stdout_hex':(e.stdout or b'').hex(),'stderr_hex':(e.stderr or b'').hex()}
def work(item):
 rel,h=item;path=root/rel;case={'source':rel,'source_sha256':h}
 with tempfile.TemporaryDirectory(prefix='sn-original-corpus-current-') as tmp:
  exe=Path(tmp)/path.stem;case['compile']=call([compiler,path,'--no-install','--target','rust','-O0','-g','-o',exe],120)
  if case['compile']['status']!=0:case['classification']='Rust compile failure';return case
  run=case['run']=call([exe],10,merged=True);oracle=path.with_suffix('.expected');panic=path.with_suffix('.panic').exists();expected=oracle.read_bytes() if oracle.exists() else None
  case['expects_panic']=panic
  if expected is not None:case['expected_sha256']=hashlib.sha256(expected).hexdigest()
  if run['status']=='timeout':label='Rust execution timeout'
  elif (run['status']==0)==panic:label='Rust exit violates original contract'
  elif expected is not None and bytes.fromhex(run['stdout_hex']).replace(b'\r\n',b'\n').replace(b'\r',b'\n')!=expected.replace(b'\r\n',b'\n').replace(b'\r',b'\n'):label='Rust original output oracle mismatch'
  elif expected is not None:label='Original output and exit contracts pass'
  else:label='Original exit contract passes; no original output oracle'
  case['classification']=label
 return case
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for future in concurrent.futures.as_completed([pool.submit(work,item) for item in sorted(sources.items())]):
  case=future.result();report['cases'].append(case)
  if len(report['cases'])%25==0 or 'pass' not in case['classification'].lower():
   report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));(folder/'current-validation.partial.json').write_text(json.dumps(report,indent=2)+'\n');print(len(report['cases']),case['source'],case['classification'],flush=True)
report['cases'].sort(key=lambda c:c['source']);report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));report['finished']=time.time();report['binary_unchanged']=hashlib.sha256(compiler.read_bytes()).hexdigest()==report['compiler_sha256'];report['all_sources_and_oracles_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in ref['compiler_source_sha256'].items());(folder/'current-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],flush=True)
