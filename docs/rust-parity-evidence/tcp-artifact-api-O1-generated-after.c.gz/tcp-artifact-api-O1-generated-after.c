#include "sn_types.h"
__sn__TcpStream * __sn_package_2_call_0(char *);
SnArray * __sn_package_2_call_1(__sn__TcpStream *, long long);
SnArray * __sn_package_2_call_2(__sn__TcpStream *);
char * __sn_package_2_call_3(__sn__TcpStream *);
char * __sn_package_2_call_4(__sn__TcpStream *);
void __sn_package_2_call_5(__sn__TcpStream *);
__sn__TcpListener * __sn_package_2_call_6(char *);
__sn__TcpStream * __sn_package_2_call_7(__sn__TcpListener *);
__sn__TcpStream * __sn_package_2_call_8(__sn__TcpListener *, long long);
void __sn_package_2_call_9(__sn__TcpListener *);
bool descriptorClosed(long long);
long long inputState();
long long makeWake();
void closeWake(long long);



__sn__TcpStream * noStream() {

    return NULL;}

__sn__TcpListener * noListener() {

    return NULL;}

bool defaults() {

    sn_auto_TcpStream __sn__TcpStream * __sn__stream = ({
        __sn__TcpStream *__tmp__ = __sn__TcpStream__new();
        __tmp__->socket_fd = 0LL;
        __tmp__->remote_addr = NULL;
        __tmp__->internal = NULL;
        __tmp__;
    });

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = ({
        __sn__TcpListener *__tmp__ = __sn__TcpListener__new();
        __tmp__->socket_fd = 0LL;
        __tmp__->bound_port = 0LL;
        __tmp__;
    });

    return (((((__sn__stream->socket_fd == 0LL) && (__sn__stream->remote_addr == NULL)) && (__sn__stream->internal == NULL)) && (__sn__listener->socket_fd == 0LL)) && (__sn__listener->bound_port == 0LL));}


long long __sn__releasedListener() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");

    return __sn__listener->socket_fd;}


long long __sn__releasedAccepted() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");

    sn_auto_str char * __sn____chain_tmp_0 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });

    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_10(__sn____chain_tmp_0);

    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_21(__sn__listener);

    return __sn__server->socket_fd;}


SnArray * __sn__escapedBytes() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");

    sn_auto_str char * __sn____chain_tmp_1 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });

    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_10(__sn____chain_tmp_1);

    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_21(__sn__listener);

    ({ sn_auto_arr SnArray *__al_tmp_0__ = ({
            SnArray *__al__ = sn_array_new(sizeof(unsigned char), 4);
            __al__->elem_tag = SN_TAG_BYTE;
    
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)0 });
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)128 });
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)255 });
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)42 });
            __al__;
        }); __sn_package_2_call_14(__sn__client, __al_tmp_0__); });
    

    __sn_package_2_call_19(__sn__client);
    

    return __sn_package_2_call_12(__sn__server);}


char * __sn__escapedLine() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");

    sn_auto_str char * __sn____chain_tmp_2 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });

    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_10(__sn____chain_tmp_2);

    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_21(__sn__listener);

    __sn_package_2_call_15(__sn__client, "é漢");
    

    return __sn_package_2_call_13(__sn__server);}


char * __sn__escapedAddress() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");

    sn_auto_str char * __sn____chain_tmp_3 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });

    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_10(__sn____chain_tmp_3);

    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_21(__sn__listener);

    return __sn_package_2_call_16(__sn__server);}


bool __sn__rawRoundtrip() {

    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_6(":0");

    sn_auto_str char * __sn____chain_tmp_4 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });

    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_0(__sn____chain_tmp_4);

    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_7(__sn__listener);

    __sn_package_2_call_15(__sn__client, "raw");
    

    sn_auto_str char * __sn__line = __sn_package_2_call_3(__sn__server);

    sn_auto_str char * __sn__remote = __sn_package_2_call_4(__sn__server);

    sn_auto_arr SnArray * __sn__empty = __sn_package_2_call_1(__sn__server, 0LL);

    ({ sn_auto_arr SnArray *__al_tmp_0__ = ({
            SnArray *__al__ = sn_array_new(sizeof(unsigned char), 3);
            __al__->elem_tag = SN_TAG_BYTE;
    
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)0 });
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)128 });
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)255 });
            __al__;
        }); __sn_package_2_call_14(__sn__client, __al_tmp_0__); });
    

    __sn_package_2_call_5(__sn__client);
    

    sn_auto_arr SnArray * __sn__data = __sn_package_2_call_2(__sn__server);

    __sn_package_2_call_5(__sn__client);
    

    __sn_package_2_call_5(__sn__server);
    

    __sn_package_2_call_9(__sn__listener);
    

    return (((((((strcmp(__sn__line, "raw") == 0) && __sn___startsWith(&__sn__remote, "127.0.0.1:")) && (sn_array_length(__sn__empty) == 0LL)) && (sn_array_length(__sn__data) == 3LL)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 0LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)0)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 1LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)128)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 2LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)255));}


int main() {
    long long __sn__before = inputState();
    printf("%s\n", (defaults()) ? "true" : "false");
    
    printf("%s\n", ((inputState() == __sn__before)) ? "true" : "false");
    
    sn_auto_TcpStream __sn__TcpStream * __sn__missing = noStream();
    printf("%s\n", ((!__sn_package_2_call_18(__sn__missing))) ? "true" : "false");
    
    printf("%s\n", ((((({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_11(__sn__missing, 0LL); sn_array_length(__len_tmp__); }) == 0LL) && (({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_12(__sn__missing); sn_array_length(__len_tmp__); }) == 0LL)) && ({char *__sct0__=__sn_package_2_call_13(__sn__missing);bool __scr__=(strcmp(__sct0__,"")==0);free(__sct0__);__scr__;}))) ? "true" : "false");
    
    printf("%s\n", ((({char *__sct0__=__sn_package_2_call_16(__sn__missing);bool __scr__=(strcmp(__sct0__,"")==0);free(__sct0__);__scr__;}) && (({ sn_auto_arr SnArray *__al_tmp_0__ = ({
            SnArray *__al__ = sn_array_new(sizeof(unsigned char), 1);
            __al__->elem_tag = SN_TAG_BYTE;
    
    
            sn_array_push(__al__, &(unsigned char){ (unsigned char)1 });
            __al__;
        }); __sn_package_2_call_14(__sn__missing, __al_tmp_0__); }) == 0LL))) ? "true" : "false");
    
    __sn_package_2_call_17(__sn__missing, 0LL);
    
    __sn_package_2_call_15(__sn__missing, "ignored");
    
    __sn_package_2_call_19(__sn__missing);
    
    sn_auto_TcpListener __sn__TcpListener * __sn__missingListener = noListener();
    printf("%s\n", ((__sn_package_2_call_23(__sn__missingListener) == 0LL)) ? "true" : "false");
    
    __sn_package_2_call_24(__sn__missingListener);
    
    printf("%s\n", (descriptorClosed(__sn__releasedListener())) ? "true" : "false");
    
    printf("%s\n", (descriptorClosed(__sn__releasedAccepted())) ? "true" : "false");
    
    sn_auto_arr SnArray * __sn__data = __sn__escapedBytes();
    printf("%s\n", ((((((sn_array_length(__sn__data) == 4LL) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 0LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)0)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 1LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)128)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 2LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)255)) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 3LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)42))) ? "true" : "false");
    
    __sn__arr_push(&__sn__data, (unsigned char)9);
    
    printf("%s\n", (((sn_array_length(__sn__data) == 5LL) && ((((unsigned char *)__sn__data->data)[({ long long __ai__ = 4LL; __ai__ < 0 ? __ai__ + __sn__data->len : __ai__; })]) == (unsigned char)9))) ? "true" : "false");
    
    printf("%s\n", (({char *__sct0__=__sn__escapedLine();bool __scr__=(strcmp(__sct0__,"é漢")==0);free(__sct0__);__scr__;})) ? "true" : "false");
    
    sn_auto_str char * __sn____chain_tmp_5 = __sn__escapedAddress();
    printf("%s\n", (__sn___startsWith(&__sn____chain_tmp_5, "127.0.0.1:")) ? "true" : "false");
    
    printf("%s\n", (__sn__rawRoundtrip()) ? "true" : "false");
    
    sn_auto_TcpListener __sn__TcpListener * __sn__listener = __sn_package_2_call_20(":0");
    sn_auto_TcpListener __sn__TcpListener * __sn__aliasListener = __sn__TcpListener_retain(__sn__listener);
    printf("%s\n", (((__sn__aliasListener->socket_fd == __sn__listener->socket_fd) && (__sn__listener->bound_port == __sn_package_2_call_23(__sn__listener)))) ? "true" : "false");
    
    sn_auto_str char * __sn____chain_tmp_6 = ({
            sn_auto_str char *__is_p0__ = sn_strdup("127.0.0.1:");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn_package_2_call_23(__sn__listener)));
            sn_str_concat_multi(2, __is_p0__, __is_p1__);
        });
    sn_auto_TcpStream __sn__TcpStream * __sn__client = __sn_package_2_call_10(__sn____chain_tmp_6);
    sn_auto_TcpStream __sn__TcpStream * __sn__server = __sn_package_2_call_21(__sn__listener);
    sn_auto_TcpStream __sn__TcpStream * __sn__alias = __sn__TcpStream_retain(__sn__server);
    printf("%s\n", ((((__sn__alias->socket_fd == __sn__server->socket_fd) && (__sn__alias->internal == __sn__server->internal)) && (__sn__server->remote_addr != NULL))) ? "true" : "false");
    
    __sn_package_2_call_17(__sn__alias, 0LL);
    
    printf("%s\n", ((({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_11(__sn__alias, 4LL); sn_array_length(__len_tmp__); }) == 0LL)) ? "true" : "false");
    
    __sn_package_2_call_17(__sn__alias, 2000LL);
    
    __sn_package_2_call_15(__sn__client, "shared");
    
    printf("%s\n", (({char *__sct0__=__sn_package_2_call_13(__sn__server);bool __scr__=(strcmp(__sct0__,"shared")==0);free(__sct0__);__scr__;})) ? "true" : "false");
    
    __sn_package_2_call_19(__sn__client);
    
    __sn_package_2_call_19(__sn__client);
    
    printf("%s\n", ((((!__sn_package_2_call_18(__sn__client)) && (({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_11(__sn__server, 4LL); sn_array_length(__len_tmp__); }) == 0LL)) && (({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_12(__sn__server); sn_array_length(__len_tmp__); }) == 0LL))) ? "true" : "false");
    
    __sn_package_2_call_19(__sn__alias);
    
    printf("%s\n", (((((!__sn_package_2_call_18(__sn__server)) && (__sn__server->socket_fd == (-1LL))) && (__sn__server->internal == NULL)) && (__sn__server->remote_addr == NULL))) ? "true" : "false");
    
    __sn_package_2_call_24(__sn__aliasListener);
    
    printf("%s\n", ((__sn__listener->socket_fd == (-1LL))) ? "true" : "false");
    
    sn_auto_TcpListener __sn__TcpListener * __sn__signalListener = __sn_package_2_call_20(":0");
    long long __sn__wakeFD = makeWake();
    sn_auto_TcpStream __sn__TcpStream * __sn__sentinel = __sn_package_2_call_22(__sn__signalListener, __sn__wakeFD);
    printf("%s\n", (((!__sn_package_2_call_18(__sn__sentinel)) && (({ sn_auto_arr SnArray *__len_tmp__ = __sn_package_2_call_12(__sn__sentinel); sn_array_length(__len_tmp__); }) == 0LL))) ? "true" : "false");
    
    closeWake(__sn__wakeFD);
    
    __sn_package_2_call_24(__sn__signalListener);
    
    sn_auto_TcpListener __sn__TcpListener * __sn__rawListener = __sn_package_2_call_6(":0");
    long long __sn__rawWake = makeWake();
    sn_auto_TcpStream __sn__TcpStream * __sn__rawSentinel = __sn_package_2_call_8(__sn__rawListener, __sn__rawWake);
    printf("%s\n", ((!__sn_package_2_call_18(__sn__rawSentinel))) ? "true" : "false");
    
    closeWake(__sn__rawWake);
    
    __sn_package_2_call_5(__sn__rawSentinel);
    
    __sn_package_2_call_9(__sn__rawListener);
    
    fflush(stdout);
    return 0;
}
