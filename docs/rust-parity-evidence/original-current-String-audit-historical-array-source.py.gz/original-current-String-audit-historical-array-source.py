import hashlib,json,subprocess,tempfile
from pathlib import Path
root=Path.cwd();folder=root/'.sn/string-call-owners-goal/original-corpus';source=subprocess.check_output(['git','show','79c20b:tests/exploratory/test_limitation_closure_array.sn']);assert hashlib.sha256(source).hexdigest()=='182d6478a812915ecfcc40bc130b7cc88cb841bf7d3a7ec41ef0b6299ae36978'
r={'historical_ref':'79c20b','source':'tests/exploratory/test_limitation_closure_array.sn','source_sha256':hashlib.sha256(source).hexdigest(),'compiler_sha256':hashlib.sha256((root/'bin/sn').read_bytes()).hexdigest(),'cases':[],'scope':'Exact historical source staged separately; current synchronized goal-start program unchanged. Original has no output oracle and unsynchronized C array mutation; execution-only Rust evidence, no defined C semantic parity credit.'}
with tempfile.TemporaryDirectory(prefix='sn-original-historical-array-') as tmp:
 app=Path(tmp);path=app/'test_limitation_closure_array.sn';path.write_bytes(source)
 for opt in ['-O0','-O1','-O2']:
  for mode in ['default','checked','unchecked']:
   exe=app/'test_limitation_closure_array';cmd=[root/'bin/sn',path,'--no-install','--target','rust',opt,'-o',exe]
   if mode!='default':cmd.append('--'+mode)
   c={'opt':opt,'mode':mode,'targets':{}}
   for phase,command in [('compile',cmd),('run',[exe])]:
    if phase=='run' and c['targets']['compile']['status']:continue
    p=subprocess.run([str(x) for x in command],cwd=root,capture_output=True,timeout=120);c['targets'][phase]={'status':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()}
   r['cases'].append(c);print(opt,mode,c['targets']['compile']['status'],c['targets'].get('run',{}).get('status'),flush=True)
r['passed']=all(c['targets']['compile']['status']==0 and c['targets'].get('run',{}).get('status')==0 for c in r['cases']);(folder/'historical-array-source.json').write_text(json.dumps(r,indent=2)+'\n')
