import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));from tcp_artifact_controls import FIELDS,BACKING
compiler=root/'bin/sn';sdk=(root/'.sn/sdk-native-integration').resolve();report={'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'source':FIELDS,'backing':BACKING,'cases':[]}
with tempfile.TemporaryDirectory(prefix='sn-tcp-copy-reference-') as folder:
 app=Path(folder);(app/'.sn').mkdir();(app/'.sn/sindarin-pkg-sdk').symlink_to(sdk,target_is_directory=True);(app/'control.sn').write_text(FIELDS);(app/'control.sn.c').write_text(BACKING)
 for debug in (False,True):
  exe=app/'client.exe';cmd=[compiler,'control.sn','--no-install','--target','c','-O0','-o',exe]+(['-g'] if debug else []);p=subprocess.run(list(map(str,cmd)),cwd=app,capture_output=True,timeout=180);case={'debug':debug,'compile_status':p.returncode,'compile_stderr_hex':p.stderr.hex()}
  if p.returncode==0:
   p=subprocess.run([exe],cwd=app,capture_output=True,timeout=30);case.update(run_status=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex())
  report['cases'].append(case);(root/'.sn/tcp-artifact-goal/legacy-field-copy.json').write_text(json.dumps(report,indent=2)+'\n');print(debug,case['compile_status'],case.get('run_status'),flush=True)
  if case['compile_status']:print(bytes.fromhex(case['compile_stderr_hex']).decode(errors='replace')[-3000:])
  else:print(bytes.fromhex(case['stdout_hex']).decode(),bytes.fromhex(case['stderr_hex']).decode(errors='replace')[-4000:])
