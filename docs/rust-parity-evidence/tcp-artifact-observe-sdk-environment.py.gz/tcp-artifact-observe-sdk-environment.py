import hashlib,json,os,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/tcp-artifact-goal';seen=set()
while seen!={'normal','sanitized'}:
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   argv=(proc/'cmdline').read_bytes().split(b'\0')
   if len(argv)<2 or argv[1]!=b'scripts/check_sdk_artifact.py' or (proc/'cwd').resolve()!=root:continue
   env=dict(entry.split(b'=',1) for entry in (proc/'environ').read_bytes().split(b'\0') if b'=' in entry)
   keys=('SN_CC','SN_CFLAGS','SN_RELEASE_CFLAGS','SN_RUSTFLAGS','ASAN_OPTIONS','UBSAN_OPTIONS')
   selected={key:env.get(key.encode(),b'').decode() or None for key in keys}
   phase='sanitized' if 'sanitize=' in (selected['SN_CFLAGS'] or '') else 'normal'
   if phase in seen:continue
   report={'command':[part.decode() for part in argv if part],'cwd':str(root),'observed_pid':int(proc.name),'observed_environment':selected,'compiler_sha256':hashlib.sha256((root/'bin/sn').read_bytes()).hexdigest(),'oracle_script_sha256':hashlib.sha256((root/'scripts/check_sdk_artifact.py').read_bytes()).hexdigest(),'builder_script_sha256':hashlib.sha256((root/'scripts/build_sdk_package.py').read_bytes()).hexdigest(),'observed_at':time.time()}
   (folder/('full-sdk-'+phase+'-execution.json')).write_text(json.dumps(report,indent=2)+'\n');seen.add(phase);print('Observed',phase,flush=True)
  except (OSError,ValueError):pass
 time.sleep(1)
