from pathlib import Path
import json,gzip,hashlib,re,subprocess
root=Path.cwd();folder=root/'.sn/record-ref-goal';dest=root/'docs/rust-parity-evidence';sha=lambda b:hashlib.sha256(b).hexdigest()
exec((folder/'verify-final.py').read_text())
audit=json.loads((folder/'method-original-corpus/all-mode-discovery.json').read_text());print('audit keys',list(audit))
assert audit['compiler_sha256']==sha((root/'bin/sn').read_bytes())
assert audit['binary_unchanged'] and audit['all_sources_and_oracles_unchanged']
assert len(audit['cases'])==12285
assert audit['counts']=={
 'Raw C/Rust agreement and original exit contract; no original output oracle':1854,
 'Raw C/Rust agreement and frozen original output/exit contracts':10418,
 'C undefined unsynchronized concurrent mutation; no parity credit':9,
 'C undefined unchecked integer division by zero; no parity credit':4},audit['counts']
assert all(target['compile']['status']==0 for case in audit['cases'] for target in case['targets'].values())
report={'status':'Complete final-binary Linux validation; own hosted acceptance remains required.','compiler_sha256':sha((root/'bin/sn').read_bytes()),'base':'7a3e646bd939bf6ad7c9a031df1c99b3405be28e','full_C':3244,'full_Rust':1099,'generation_oracles_unchanged':508,'direct_C_Rust_pairs_normal':144,'direct_C_Rust_pairs_C_sanitized':144,'independent_provider_source_sealed_cases_normal':36,'independent_provider_source_sealed_cases_C_sanitized':36,'CI_helpers':27,'gate_definitions':242,'platform_executions':548,'platform_groups':41,'preserved_compiler_source_oracle_hashes':2523,'preserved_SDK_source_oracle_hashes':87,'retained_reports':[],'original_corpus_mode_pairs':12285,'successful_original_compiles':24570,'frozen_original_output_exit_agreements':10418,'original_exit_only_agreements':1854,'excluded_C_undefined_modes':13,'scope':'Direct integral field compounds of explicit reference value-record parameters, physical-place alias views with transitive free/static/instance calls, recursion and whole-record rebinding. Public package exports remain scalar; wider public record ABI, arbitrary computed/owned places, captures, floating/self-RHS language gaps and final platform acceptance remain separate.'}
files=[folder/n for n in ['method-full-C.log','method-full-Rust.log','method-controls-normal.log','method-controls-sanitized.log','method-package-normal.log','method-package-sanitized.log','method-ci-helpers.log','method-format.log','method-source-preservation.json','method-original-modes.log','audit-method-original-modes.py','verify-final.py','accepted-before-quick.json','accepted-before-quick.log','method-boundary-prefinal.log','method-boundary-prefinal/discovery.json','C-shadow-exclusion.json','exploratory-C-rejections.json','computed-fields/discovery.json','capture-snapshot/discovery.json']]
files += [root/'.sn'/n for n in ['reference-record-compounds.json','reference-record-compounds-sanitized.json','package-reference-record-compounds.json','package-reference-record-compounds-sanitized.json']]
files += [folder/'method-original-corpus/all-mode-discovery.json']
for p in files:
 name='reference-record-'+str(p.relative_to(folder) if p.is_relative_to(folder) else p.relative_to(root/'.sn')).replace('/','-')+'.gz';target=dest/name;target.write_bytes(gzip.compress(p.read_bytes(),mtime=0));report['retained_reports'].append({'path':str(target.relative_to(root)),'sha256':sha(target.read_bytes())})
(dest/'reference-record-compounds-local-validation.json').write_text(json.dumps(report,indent=2)+'\n')
