import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path.cwd();folder=root/'.sn/zlib-goal/CI-failure-40206567956';dest=root/'docs/rust-parity-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binary=sha(root/'bin/sn')
r=json.loads((folder/'validation.json').read_text());assert r['passed'] and r['binary_unchanged'] and len(r['checks'])==19 and all(c['status']==0 for c in r['checks']) and r['compiler_sha256']==binary
paths={}
for stem,count in [('package-borrowed-scalar-memory',72),('sdk-zlib-artifact',108),('zlib-header-widths',108),('rust-integer-match-patterns',63),('package-integer-match-patterns',36),('c-array-call-arguments',18)]:
 for suffix in ('','-sanitized'):
  p=root/'.sn'/(stem+suffix+'.json');v=json.loads(p.read_text());assert v['passed'] and len(v['cases'])==count and v['compiler_sha256']==binary,p
  assert ('sanitize=' in (v['environment'].get('SN_CFLAGS') or ''))==bool(suffix),p
  if stem=='zlib-header-widths':assert v['script_sha256']==sha(root/'scripts/check_zlib_header_widths.py')
  paths['report-'+p.name]=p
for name,count in [('C',3243),('Rust',1099)]:
 p=folder/('full-'+name+'.log');text=re.sub(r'\x1b\[[0-9;]*m','',p.read_text());assert 'All tests passed!' in text and sum(map(int,re.findall(r'Results: (\d+) passed, 0 failed',text)))==count,name
for name,count in [('imports',52),('artifacts',22),('helpers',27)]:assert f'Ran {count} tests' in (folder/(name+'.log')).read_text(),name
for name in ('SDK21-normal','SDK21-sanitized'):
 p=folder/(name+'.json');d=json.loads(p.read_text());assert d['passed'] and len(d['cases'])==828 and len(d['modules'])==21 and d['compiler_sha256']==binary and d['public_sources_preserved'] and d['backing_sources_removed_for_prebuilt'];paths[name]=p
for environment in ('normal','sanitized'):
 p=folder/('SDK21-'+environment+'-execution.json');v=json.loads(p.read_text());assert v['compiler_sha256']==binary and ('sanitize=' in v['observed_environment']['SN_CFLAGS'])==(environment=='sanitized');paths[p.name]=p
p=folder/'original-corpus/all-mode-discovery.json';m=json.loads(p.read_text());assert len(m['cases'])==12285 and m['compiler_sha256']==binary and m['binary_unchanged'] and m['all_sources_and_oracles_unchanged'];assert sorted(m['counts'].values())==[4,9,1854,10418] and all(t['compile']['status']==0 for c in m['cases'] for t in c['targets'].values())
frozen=json.loads(gzip.decompress((dest/'math-source-preservation-local.json.gz').read_bytes()))['compiler_source_sha256'];assert len(frozen)==2523
for rel,h in frozen.items():assert sha(root/rel)==h,rel
sdk=(root/'.sn/sdk-native-integration').resolve();preserved=json.loads((sdk/'docs/net/udp-native-validation.json').read_text())['source_preservation'];assert preserved['file_count']==87
for rel,h in preserved['sha256'].items():assert sha(sdk/rel)==h,rel
base=json.loads(subprocess.check_output(['git','show','4a0ebda6:scripts/ci/gates.json']));catalog=json.loads((root/'scripts/ci/gates.json').read_text());by={g['id']:g for g in catalog['gates']};assert len(by)==234 and all(by[g['id']]==g for g in base['gates']) and sum(1 if g['linux_only'] else 3 for g in by.values())==532
for p in [folder/'validation.json',folder/'validate-correction.py',folder/'validation-driver.log',folder/'audit-original-modes.py',folder/'original-modes.log',folder/'original-corpus/all-mode-discovery.json',folder/'integer-capture-after.log',folder/'header-widths-after-quick-3.log',folder/'header-widths-portable-normal.log',folder/'header-widths-portable-sanitized.log']+[folder/(c['name']+'.log') for c in r['checks']]:paths[str(p.relative_to(folder)).replace('/','-')]=p
paths['retain-correction.py']=folder/'retain-correction.py'
paths['observe-sdk-environments.py']=folder/'observe-sdk-environments.py'
retained=[]
for name,p in paths.items():
 out=dest/('zlib-Windows-correction-'+name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));retained.append({'path':str(out.relative_to(root)),'sha256':sha(out),'raw_sha256':sha(p)})
modified=subprocess.check_output(['git','diff','--name-only','4a0ebda6'],text=True).splitlines();new=['scripts/check_zlib_header_widths.py','tests/package/integer_match_capture.py'];assert not any(p.endswith(('.sn','.expected','.expected.c','.expected.rs')) for p in modified)
proof={'status':'Combined required-CI correction passes complete local validation; own Linux/macOS/Windows acceptance remains required.','base':'4a0ebda6ca43940bba0502cf5ef05971844c9ce9','required_failed_CI':40206567956,'required_failure_evidence':'docs/rust-parity-evidence/zlib-Windows-correction-required-failure.json','compiler_sha256':binary,'source_and_script_sha256':{p:sha(root/p) for p in modified+new if not p.startswith('docs/')},'composed_commands':19,'supplemental_portable_header_commands':2,'full_C':3243,'full_Rust':1099,'strict_32_64_bit_header_cases_each_environment':108,'real_zlib_cases_each_environment':108,'integer_match_pairs_each_environment':63,'independent_integer_package_cases_each_environment':36,'borrowed_memory_cases_each_environment':72,'slice_loan_and_order_cases_each_environment':18,'SDK21_cases_each_environment':828,'imports':52,'artifacts':22,'CI_helpers':27,'fresh_original_sources':1365,'fresh_original_mode_cases':12285,'fresh_successful_C_Rust_compilations':24570,'mode_classifications':m['counts'],'known_C_undefined_modes_not_credited':13,'source_preservation':{'compiler_sources_and_oracles_unchanged':2523,'SDK_sources_and_oracles_unchanged':87,'public_SDK_modules_unchanged':28},'gate_definitions':234,'platform_executions':532,'groups':41,'all233_published_gate_definitions_unchanged':True,'scope':'Typed legacy zlib header reference bridges, compatible-address preservation in canonical bridges, and isolated integer-match evidence directories. Mock headers test adapters only; actual zlib behavior is verified separately. Fresh original-corpus Linux agreement does not establish all C-defined semantics or final platform parity. Full parity goal remains open.','retained_reports':retained}
(dest/'zlib-Windows-correction-local-validation.json').write_text(json.dumps(proof,indent=2)+'\n');print('Retained',len(retained),'correction reports with exact compiler and source hashes')
