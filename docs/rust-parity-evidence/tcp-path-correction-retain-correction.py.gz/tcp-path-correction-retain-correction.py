import gzip, hashlib, json, re, subprocess
from pathlib import Path
root=Path.cwd(); folder=root/'.sn/tcp-path-goal'; dest=root/'docs/rust-parity-evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
binary=sha(root/'bin/sn'); assert binary==sha(folder/'audit-compiler/sn')
files=[]
for name,count in [('C',3244),('Rust',1099)]:
    p=folder/f'full-{name}.log'; text=re.sub(r'\x1b\[[0-9;]*m','',p.read_text())
    assert 'All tests passed!' in text and sum(map(int,re.findall(r'Results: (\d+) passed, 0 failed',text)))==count
    files.append(p)
for name,count in [('imports',53),('artifacts',22),('helpers',27)]:
    p=folder/(name+'.log'); text=p.read_text();assert f'Ran {count} tests' in text and '\nOK\n' in text
    files.append(p)
assert 'All files already formatted.' in (folder/'format.log').read_text()
for name in ('symlink-before-valid-fixture.log','symlink-after.log'):
    text=(folder/name).read_text()
    assert ('FAILED (failures=4)' in text if 'before' in name else '\nOK\n' in text)
    files.append(folder/name)
pair=read(folder/'SDK-alias-before-after.json');assert len(pair)==2
assert pair[0]['status']!=0 and b'cannot also compile per-application @source backing' in bytes.fromhex(pair[0]['stderr_hex'])
assert pair[1]['status']==0 and pair[1]['compiler_sha256']==binary
for phase in ('normal','sanitized'):
    p=folder/f'full-sdk-{phase}.json'; d=read(p)
    assert d['passed'] and len(d['cases'])==864 and len(d['modules'])==22 and d['compiler_sha256']==binary
    assert d['public_sources_preserved'] and d['backing_sources_removed_for_prebuilt']
    e=read(folder/f'full-sdk-{phase}-execution.json'); assert e['compiler_sha256']==binary
    assert e['oracle_script_sha256']==sha(root/'scripts/check_sdk_artifact.py')
    assert e['builder_script_sha256']==sha(root/'scripts/build_sdk_package.py')
    assert ('sanitize=' in (e['observed_environment']['SN_CFLAGS'] or ''))==(phase=='sanitized')
    assert e['observed_TMPDIR']!=e['resolved_TMPDIR']
    files.extend([p,folder/f'full-sdk-{phase}.log',folder/f'full-sdk-{phase}-execution.json'])
    p=root/'.sn'/('sdk-tcp-artifact'+('-sanitized' if phase=='sanitized' else '')+'.json');d=read(p)
    assert d['passed'] and len(d['cases'])==144 and len(d['contract_rejections'])==16 and d['compiler_sha256']==binary
    assert d['oracle_script_sha256']==sha(root/'scripts/check_sdk_tcp_artifact.py') and d['controls_script_sha256']==sha(root/'scripts/tcp_artifact_controls.py')
    files.extend([p,folder/('TCP-'+phase+'.log')])
m=read(folder/'original-corpus/all-mode-discovery.json')
assert len(m['cases'])==12285 and m['compiler_sha256']==binary and m['binary_unchanged'] and m['all_sources_and_oracles_unchanged']
assert sorted(m['counts'].values())==[4,9,1854,10418]
assert all(v['compile']['status']==0 for c in m['cases'] for v in c['targets'].values())
s=read(folder/'source-preservation.json');assert s['compiler_sha256']==binary
assert len(s['compiler_source_sha256'])==2523 and len(s['SDK_source_sha256'])==87
for name,digest in s['compiler_source_sha256'].items():assert sha(root/name)==digest
sdk=(root/'.sn/sdk-native-integration').resolve()
for name,digest in s['SDK_source_sha256'].items():assert sha(sdk/name)==digest
catalog=read(root/'scripts/ci/gates.json');old=json.loads(subprocess.check_output(['git','show','ad98351e:scripts/ci/gates.json'],text=True))
assert catalog==old and len(catalog['gates'])==238
assert sum(1 if g['linux_only'] else 3 for g in catalog['gates'])==540
changed=subprocess.check_output(['git','diff','--name-only','ad98351e'],text=True).splitlines()
assert not any(n.endswith(('.sn','.expected','.expected.c','.expected.rs')) for n in changed)
files.extend(folder/name for name in ('SDK-alias-before-after.json','SDK-alias-before.log','SDK-alias-after.log',
    'source-preservation.json','format.log','audit-original-modes.py','original-modes.log','retain-correction.py'))
files.append(folder/'original-corpus/all-mode-discovery.json')
retained=[]
for p in files:
    name=p.relative_to(folder).as_posix().replace('/','-') if p.is_relative_to(folder) else p.name
    out=dest/('tcp-path-correction-'+name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    retained.append(dict(path=out.relative_to(root).as_posix(),sha256=sha(out),raw_sha256=sha(p)))
proof=dict(status='Complete local path-alias correction validation. Own corrected integrated hosted CI remains required.',
    failing_revision='ad98351ec3267506ed9c7a642d33c56dfb78ad43',failed_CI=40234115101,compiler_sha256=binary,
    source_and_script_sha256={n:sha(root/n) for n in changed if not n.startswith('docs/')},
    full_C=3244,full_Rust=1099,native_import_tests=53,native_artifact_tests=22,CI_helper_tests=27,
    regression='8 real/aliased source/sealed C/Rust executions and4 undeclared-source rejections in existing native-import gate; Windows uses a directory symlink or project-local junction.',
    SDK22_cases_each_environment=864,TCP_artifact_cases_each_environment=144,TCP_separate_copy_contract_rejections_each_environment=16,
    SDK_environment='Both whole-SDK and TCP matrices execute with TMPDIR behind a directory symlink, reproducing the macOS alias condition on Linux.',
    fresh_original_sources=1365,fresh_mode_cases=12285,fresh_successful_compilations=24570,mode_classifications=m['counts'],
    known_C_undefined_modes_not_credited=13,compiler_source_oracle_hashes_preserved=2523,SDK_source_oracle_hashes_preserved=87,
    gate_definitions=238,platform_executions=540,platform_groups=41,all_published_gates_unchanged=True,
    scope='Resolve actual backing-source identity, including removed files and parent directories, without weakening the independent-artifact backing guard. SDK22 and broader language/ownership/final platform acceptance remain unachieved until their required evidence is complete.',
    retained_reports=retained)
(dest/'tcp-path-correction-local-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print('Retained complete correction proof:',len(retained),'reports')
