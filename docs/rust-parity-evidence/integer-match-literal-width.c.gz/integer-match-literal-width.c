#include <stdint.h>
#include <stdio.h>
#define KIND(x) _Generic((x), long long:64, unsigned long long:65, __int128:128, unsigned __int128:129, default:0)
int main(void) {
 uint64_t middle=UINT64_C(9223372036854775808);
 printf("kind=%d equal=%d\n",KIND(-9223372036854775808LL),middle == -9223372036854775808LL);
 return 0;
}
