#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#include "sn_minimal.h"

long long __sn__run_closure(void *);

typedef struct {
    void * arg0;
    int _padding;
} __ThreadArgs_0__;

static void *__thread_wrapper_0__(void *arg) {
    SnThread *__th__ = (SnThread *)arg;
    __ThreadArgs_0__ *args = (__ThreadArgs_0__ *)__th__->result;
    __ThreadArgs_0__ __args_copy__ = *args;
    args = &__args_copy__;

    long long __result__ = __sn__run_closure(args->arg0);
    free(__th__->result); __th__->result = NULL;
    if (!__th__->result) __th__->result = calloc(1, sizeof(long long));
    *(long long *)__th__->result = __result__;
    sn_thread_release(__th__);
    return NULL;
}

typedef struct {
    void * arg0;
    int _padding;
} __ThreadArgs_1__;

static void *__thread_wrapper_1__(void *arg) {
    SnThread *__th__ = (SnThread *)arg;
    __ThreadArgs_1__ *args = (__ThreadArgs_1__ *)__th__->result;
    __ThreadArgs_1__ __args_copy__ = *args;
    args = &__args_copy__;

    long long __result__ = __sn__run_closure(args->arg0);
    free(__th__->result); __th__->result = NULL;
    if (!__th__->result) __th__->result = calloc(1, sizeof(long long));
    *(long long *)__th__->result = __result__;
    sn_thread_release(__th__);
    return NULL;
}

typedef struct {
    void * arg0;
    int _padding;
} __ThreadArgs_2__;

static void *__thread_wrapper_2__(void *arg) {
    SnThread *__th__ = (SnThread *)arg;
    __ThreadArgs_2__ *args = (__ThreadArgs_2__ *)__th__->result;
    __ThreadArgs_2__ __args_copy__ = *args;
    args = &__args_copy__;

    long long __result__ = __sn__run_closure(args->arg0);
    free(__th__->result); __th__->result = NULL;
    if (!__th__->result) __th__->result = calloc(1, sizeof(long long));
    *(long long *)__th__->result = __result__;
    sn_thread_release(__th__);
    return NULL;
}
typedef struct __Closure__ {
    void *fn;
    size_t size;
    void (*__cleanup__)(void *);
    int __rc__;
} __Closure__;

typedef struct __closure_0__ {
    void *fn;
    size_t size;
    void (*__cleanup__)(void *);
    int __rc__;
    long long *counter;
} __closure_0__;
static void __closure_0_free__(void *p) {
    __closure_0__ *cl = (__closure_0__ *)p;
    free(cl->counter);
    free(cl);
}
static void __closure_0_cleanup__(void **p) {
    if (*p) {
        free(*p);
    }
    *p = NULL;
}
#define sn_auto_closure_0 __attribute__((cleanup(__closure_0_cleanup__)))
static long long __lambda_0__(void *__closure__);


long long __sn__run_closure(void * __sn__f) {

    return ((long long (*)(void *))((__Closure__ *)__sn__f)->fn)(__sn__f);}

int main() {
    sn_auto_capture long long *__sn__counter = malloc(sizeof(long long)); *__sn__counter = 0LL;
    sn_auto_closure_0 void * __sn__increment = ({
        __closure_0__ *__cl__ = malloc(sizeof(__closure_0__));
        __cl__->fn = (void *)__lambda_0__;
        __cl__->size = sizeof(__closure_0__);
        __cl__->__cleanup__ = NULL;
        __cl__->__rc__ = 1;
        __cl__->counter = __sn__counter;
        __cl__;
    });
    long long __sn__r1 = 0; sn_auto_thread SnThread * __sn__r1__th__ = ({
        SnThread *__th__ = sn_thread_create();
    
        __ThreadArgs_0__ *__args__ = malloc(sizeof(__ThreadArgs_0__));
        __args__->arg0 = __sn__increment;
        __th__->result = __args__;
        __th__->result_size = sizeof(long long);
        pthread_create(&__th__->thread, NULL, __thread_wrapper_0__, __th__);
        __th__;
    });
    long long __sn__r2 = 0; sn_auto_thread SnThread * __sn__r2__th__ = ({
        SnThread *__th__ = sn_thread_create();
    
        __ThreadArgs_1__ *__args__ = malloc(sizeof(__ThreadArgs_1__));
        __args__->arg0 = __sn__increment;
        __th__->result = __args__;
        __th__->result_size = sizeof(long long);
        pthread_create(&__th__->thread, NULL, __thread_wrapper_1__, __th__);
        __th__;
    });
    long long __sn__r3 = 0; sn_auto_thread SnThread * __sn__r3__th__ = ({
        SnThread *__th__ = sn_thread_create();
    
        __ThreadArgs_2__ *__args__ = malloc(sizeof(__ThreadArgs_2__));
        __args__->arg0 = __sn__increment;
        __th__->result = __args__;
        __th__->result_size = sizeof(long long);
        pthread_create(&__th__->thread, NULL, __thread_wrapper_2__, __th__);
        __th__;
    });
    long long __sn__v1 = ({
        sn_auto_thread SnThread *__sync_th__ = __sn__r1__th__; __sn__r1__th__ = NULL;
        if (__sync_th__) { sn_thread_join(__sync_th__); __sn__r1 = *(long long *)__sync_th__->result; }
        __sn__r1; })
    ;
    long long __sn__v2 = ({
        sn_auto_thread SnThread *__sync_th__ = __sn__r2__th__; __sn__r2__th__ = NULL;
        if (__sync_th__) { sn_thread_join(__sync_th__); __sn__r2 = *(long long *)__sync_th__->result; }
        __sn__r2; })
    ;
    long long __sn__v3 = ({
        sn_auto_thread SnThread *__sync_th__ = __sn__r3__th__; __sn__r3__th__ = NULL;
        if (__sync_th__) { sn_thread_join(__sync_th__); __sn__r3 = *(long long *)__sync_th__->result; }
        __sn__r3; })
    ;
    { sn_auto_str char *__ps__ = ({
            sn_auto_str char *__is_p0__ = sn_strdup("Results: ");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)(__sn__v1));
            sn_auto_str char *__is_p2__ = sn_strdup(", ");
            sn_auto_str char *__is_p3__ = sn_str_fmt("%lld", (long long)(__sn__v2));
            sn_auto_str char *__is_p4__ = sn_strdup(", ");
            sn_auto_str char *__is_p5__ = sn_str_fmt("%lld", (long long)(__sn__v3));
            sn_auto_str char *__is_p6__ = sn_strdup("\n");
            sn_str_concat_multi(7, __is_p0__, __is_p1__, __is_p2__, __is_p3__, __is_p4__, __is_p5__, __is_p6__);
        }); sn_print(__ps__); };
    
    { sn_auto_str char *__ps__ = ({
            sn_auto_str char *__is_p0__ = sn_strdup("Counter: ");
            sn_auto_str char *__is_p1__ = sn_str_fmt("%lld", (long long)((*__sn__counter)));
            sn_auto_str char *__is_p2__ = sn_strdup("\n");
            sn_str_concat_multi(3, __is_p0__, __is_p1__, __is_p2__);
        }); sn_print(__ps__); };
    
    fflush(stdout);
    return 0;
}

static long long __lambda_0__(void *__closure__) {

    long long *__sn__counter = ((__closure_0__ *)__closure__)->counter;

    (*__sn__counter = sn_add_long((*__sn__counter), 1LL));
    
    return (*__sn__counter);}
