#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#include "sn_minimal.h"

long long __sn__will_panic(long long);

typedef struct {
    long long arg0;
    int _padding;
} __ThreadArgs_0__;

static void *__thread_wrapper_0__(void *arg) {
    SnThread *__th__ = (SnThread *)arg;
    __ThreadArgs_0__ *args = (__ThreadArgs_0__ *)__th__->result;
    __ThreadArgs_0__ __args_copy__ = *args;
    args = &__args_copy__;

    long long __result__ = __sn__will_panic(args->arg0);
    free(__th__->result); __th__->result = NULL;
    if (!__th__->result) __th__->result = calloc(1, sizeof(long long));
    *(long long *)__th__->result = __result__;
    sn_thread_release(__th__);
    return NULL;
}
typedef struct __Closure__ {
    void *fn;
    size_t size;
    void (*__cleanup__)(void *);
    int __rc__;
} __Closure__;


long long __sn__will_panic(long long __sn__x) {

    return (10LL / __sn__x);}

int main() {
    sn_print("Testing thread panic propagation\n");
    
    long long __sn__r = 0; sn_auto_thread SnThread * __sn__r__th__ = ({
        SnThread *__th__ = sn_thread_create();
    
        __ThreadArgs_0__ *__args__ = malloc(sizeof(__ThreadArgs_0__));
        __args__->arg0 = 0LL;
        __th__->result = __args__;
        __th__->result_size = sizeof(long long);
        pthread_create(&__th__->thread, NULL, __thread_wrapper_0__, __th__);
        __th__;
    });
    ({
        sn_auto_thread SnThread *__sync_th__ = __sn__r__th__; __sn__r__th__ = NULL;
        if (__sync_th__) { sn_thread_join(__sync_th__); __sn__r = *(long long *)__sync_th__->result; }
        __sn__r; })
    ;
    
    sn_print("FAILURE: Should not reach here - panic should have propagated\n");
    
    fflush(stdout);
    return 0;
}
