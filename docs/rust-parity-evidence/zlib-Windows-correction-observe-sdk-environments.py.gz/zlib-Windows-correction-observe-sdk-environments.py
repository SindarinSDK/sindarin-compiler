import hashlib,json,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/zlib-goal/CI-failure-40206567956';seen=set();start=time.monotonic()
while len(seen)<2 and time.monotonic()-start<3600:
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   args=p.joinpath('cmdline').read_bytes().split(b'\0')
   if args[:2]!=[b'python3',b'scripts/check_sdk_artifact.py']:continue
   environment=dict(item.split(b'=',1) for item in p.joinpath('environ').read_bytes().split(b'\0') if b'=' in item)
   observed={n:environment.get(n.encode(),b'').decode() for n in ('SN_CC','SN_CFLAGS','SN_RUSTFLAGS','ASAN_OPTIONS','UBSAN_OPTIONS')}
   name='sanitized' if 'sanitize=' in observed['SN_CFLAGS'] else 'normal'
   if name in seen:continue
   v={'pid':int(p.name),'argv':[a.decode() for a in args if a],'observed_environment':observed,'compiler_sha256':hashlib.sha256((root/'bin/sn').read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256((root/'scripts/check_sdk_artifact.py').read_bytes()).hexdigest(),'observed_at':time.time()}
   (folder/('SDK21-'+name+'-execution.json')).write_text(json.dumps(v,indent=2)+'\n');seen.add(name);print('Captured',name,int(p.name),flush=True)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 time.sleep(5)
assert len(seen)==2
