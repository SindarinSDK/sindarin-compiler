import concurrent.futures,collections,gzip,hashlib,json,os,platform,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();compiler=root/'bin/sn';folder=root/'.sn/method-struct-goal/original-corpus';folder.mkdir(exist_ok=True)
ref=json.loads(gzip.decompress((root/'docs/rust-parity-evidence/math-source-preservation-local.json.gz').read_bytes()));sources={p:h for p,h in ref['compiler_source_sha256'].items() if p.endswith('.sn')};assert len(sources)==1365
for p,h in ref['compiler_source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':platform.platform(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'started':time.time(),'source_count':1365,'modes':[(o,m) for o in ['-O0','-O1','-O2'] for m in ['default','checked','unchecked']],'scope':'Current goal-start originals: all-mode C/Rust raw discovery plus frozen-oracle comparisons. Raw agreement and sanitizer-free runs do not prove C-defined semantics. Original oracles may require arithmetic-mode adjudication; no original source/oracle changed. This is Linux discovery, not final platform acceptance.','cases':[]}
def invoke(cmd,timeout,build=False):
 try:
  p=subprocess.run([str(v) for v in cmd],cwd=root,capture_output=True,timeout=timeout)
  r={'status':p.returncode}
  for key,data in [('stdout',p.stdout),('stderr',p.stderr)]:
   if build and p.returncode==0:r[key+'_sha256']=hashlib.sha256(data).hexdigest()
   else:r[key+'_hex']=data.hex()
  return r
 except subprocess.TimeoutExpired as e:return {'status':'timeout','stdout_hex':(e.stdout or b'').hex(),'stderr_hex':(e.stderr or b'').hex()}
def work(item):
 rel,h=item;path=root/rel;oracle=path.with_suffix('.expected');expected=oracle.read_bytes() if oracle.exists() else None;out=[]
 with tempfile.TemporaryDirectory(prefix='sn-original-modes-current-') as tmp:
  for opt,mode in report['modes']:
   case={'source':rel,'source_sha256':h,'optimization':opt,'arithmetic_mode':mode,'targets':{}}
   for target in ['c','rust']:
    target_dir=Path(tmp)/target;target_dir.mkdir(exist_ok=True);exe=target_dir/path.stem;cmd=[compiler,path,'--no-install','--target',target,opt,'-o',exe]
    if mode!='default':cmd.append('--'+mode)
    result={'compile':invoke(cmd,120,True)}
    if result['compile']['status']==0:
     result['run']=invoke([exe],10);run=result['run'];combined=bytes.fromhex(run.get('stdout_hex',''))+bytes.fromhex(run.get('stderr_hex',''))
     if expected is not None and run.get('stdout_hex') and run.get('stderr_hex'):
      merged=subprocess.run([str(exe)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
      result['actual_merged_run']={'status':merged.returncode,'output_hex':merged.stdout.hex()};combined=merged.stdout
     result['original_output_oracle_matches']=None if expected is None else combined.replace(b'\r\n',b'\n').replace(b'\r',b'\n')==expected.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
     result['original_exit_contract_matches']=None if run['status']=='timeout' else ((run['status']!=0)==path.with_suffix('.panic').exists())
    case['targets'][target]=result
   c,r=case['targets']['c'],case['targets']['rust']
   if any(x['compile']['status']!=0 for x in [c,r]):label='Compilation failure; review required'
   elif rel=='tests/exploratory/test_limitation_closure_mutable.sn':label='C undefined unsynchronized concurrent mutation; no parity credit'
   elif rel=='tests/integration/test_thread_panic_propagate.sn' and (mode=='unchecked' or (opt=='-O2' and mode=='default')):label='C undefined unchecked integer division by zero; no parity credit'
   elif any(x['run']['status']=='timeout' for x in [c,r]):label='Execution timeout; review required'
   elif c['run']!=r['run']:label='C/Rust observable difference; semantic review required'
   elif any(x['original_output_oracle_matches'] is False or x['original_exit_contract_matches'] is False for x in [c,r]):label='Raw C/Rust agreement; original contract needs mode/semantic review'
   elif expected is None:label='Raw C/Rust agreement and original exit contract; no original output oracle'
   else:label='Raw C/Rust agreement and frozen original output/exit contracts'
   case['classification']=label;out.append(case)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for n,future in enumerate(concurrent.futures.as_completed([pool.submit(work,item) for item in sorted(sources.items())]),1):
  cases=future.result();report['cases'].extend(cases)
  if n%25==0 or any('difference' in c['classification'] or 'failure' in c['classification'] for c in cases):
   report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));(folder/'all-mode-discovery.partial.json').write_text(json.dumps(report,indent=2)+'\n');print(n,len(report['cases']),cases[0]['source'],report['counts'],flush=True)
report['cases'].sort(key=lambda c:(c['source'],c['optimization'],c['arithmetic_mode']));report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));report['finished']=time.time();report['binary_unchanged']=hashlib.sha256(compiler.read_bytes()).hexdigest()==report['compiler_sha256'];report['all_sources_and_oracles_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in ref['compiler_source_sha256'].items());(folder/'all-mode-discovery.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],flush=True)
