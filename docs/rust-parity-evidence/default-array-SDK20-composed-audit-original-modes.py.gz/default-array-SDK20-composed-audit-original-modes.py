import concurrent.futures,collections,gzip,hashlib,json,platform,subprocess,tempfile,time
from pathlib import Path
root=Path.cwd();compiler=root/'bin/sn';folder=root/'.sn/default-array-goal/original-corpus';folder.mkdir(exist_ok=True)
reference=Path('/home/gavin/code/sindarin/sindarin-rust-string-call-owners/.sn/string-call-owners-goal/original-corpus/all-mode-discovery.json');raw=reference.read_bytes();prior=json.loads(raw);assert prior['binary_unchanged'] and prior['all_sources_and_oracles_unchanged'] and len(prior['cases'])==12285;assert not subprocess.check_output(['git','diff','f3b2f0cf','--','src/cgen','templates/c','src/runtime','include','CMakeLists.txt'])
ref=json.loads(gzip.decompress((root/'docs/rust-parity-evidence/math-source-preservation-local.json.gz').read_bytes()));sources={p:h for p,h in ref['compiler_source_sha256'].items() if p.endswith('.sn')};assert len(sources)==1365
for p,h in ref['compiler_source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
by_source=collections.defaultdict(list)
for c in prior['cases']:assert sources[c['source']]==c['source_sha256'];by_source[c['source']].append(c)
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':platform.platform(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'started':time.time(),'source_count':1365,'C_reference_revision':prior['revision'],'C_reference_compiler_sha256':prior['compiler_sha256'],'C_reference_raw_sha256':hashlib.sha256(raw).hexdigest(),'C_backend_runtime_headers_templates_unchanged':True,'C_reference_scope':'Reuse fresh f3 mode-matched C executable results: C backend/runtime/templates/header/config code unchanged and no original source imports SDK. Rust is rerun for every original/mode. Known13 C-undefined modes receive no parity credit. This discovery is not final platform/C-defined acceptance.','cases':[]}
def invoke(cmd,timeout,build=False,merged=False):
 try:
  p=subprocess.run([str(v) for v in cmd],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT if merged else subprocess.PIPE,timeout=timeout);r={'status':p.returncode}
  for k,d in [('stdout',p.stdout or b''),('stderr',p.stderr or b'')]:
   if build and p.returncode==0:r[k+'_sha256']=hashlib.sha256(d).hexdigest()
   else:r[k+'_hex']=d.hex()
  return r
 except subprocess.TimeoutExpired as e:return {'status':'timeout','stdout_hex':(e.stdout or b'').hex(),'stderr_hex':(e.stderr or b'').hex()}
def work(item):
 rel,h=item;path=root/rel;oracle=path.with_suffix('.expected');expected=oracle.read_bytes() if oracle.exists() else None;out=[]
 with tempfile.TemporaryDirectory(prefix='sn-array-original-modes-') as tmp:
  for old in sorted(by_source[rel],key=lambda c:(c['optimization'],c['arithmetic_mode'])):
   opt,mode=old['optimization'],old['arithmetic_mode'];exe=Path(tmp)/path.stem;cmd=[compiler,path,'--no-install','--target','rust',opt,'-o',exe]
   if mode!='default':cmd.append('--'+mode)
   c={'source':rel,'source_sha256':h,'optimization':opt,'arithmetic_mode':mode,'C_reference_run':old['targets']['c']['run'],'rust':{'compile':invoke(cmd,120,True)}};r=c['rust']
   if r['compile']['status']==0:
    run=r['run']=invoke([exe],10);combined=bytes.fromhex(run.get('stdout_hex',''))+bytes.fromhex(run.get('stderr_hex',''))
    if expected is not None and run.get('stdout_hex') and run.get('stderr_hex'):
     merged=r['actual_merged_run']=invoke([exe],10,merged=True);combined=bytes.fromhex(merged.get('stdout_hex',''))
    r['original_output_oracle_matches']=None if expected is None else combined.replace(b'\r\n',b'\n').replace(b'\r',b'\n')==expected.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
    r['original_exit_contract_matches']=None if run['status']=='timeout' else ((run['status']!=0)==path.with_suffix('.panic').exists())
   if r['compile']['status']!=0:label='Rust compilation failure; review required'
   elif rel=='tests/exploratory/test_limitation_closure_mutable.sn':label='C undefined unsynchronized concurrent mutation; no parity credit'
   elif rel=='tests/integration/test_thread_panic_propagate.sn' and (mode=='unchecked' or (opt=='-O2' and mode=='default')):label='C undefined unchecked integer division by zero; no parity credit'
   elif r['run']['status']=='timeout':label='Rust execution timeout; review required'
   elif r['run']!=c['C_reference_run']:label='C reference/Rust difference; review required'
   elif not r['original_exit_contract_matches'] or r['original_output_oracle_matches'] is False:label='Original contract violation; review required'
   elif expected is None:label='C reference/Rust agreement and original exit contract only; no original output oracle'
   else:label='C reference/Rust agreement and frozen original output/exit contracts'
   c['classification']=label;out.append(c)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for n,future in enumerate(concurrent.futures.as_completed([pool.submit(work,item) for item in sorted(sources.items())]),1):
  cases=future.result();report['cases'].extend(cases)
  if n%25==0 or any('review required' in c['classification'] for c in cases):
   report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));(folder/'all-mode-discovery.partial.json').write_text(json.dumps(report,indent=2)+'\n');print(n,len(report['cases']),cases[0]['source'],report['counts'],flush=True)
report['cases'].sort(key=lambda c:(c['source'],c['optimization'],c['arithmetic_mode']));report['counts']=dict(collections.Counter(c['classification'] for c in report['cases']));report['finished']=time.time();report['binary_unchanged']=hashlib.sha256(compiler.read_bytes()).hexdigest()==report['compiler_sha256'];report['all_sources_and_oracles_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in ref['compiler_source_sha256'].items());(folder/'all-mode-discovery.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],flush=True)
