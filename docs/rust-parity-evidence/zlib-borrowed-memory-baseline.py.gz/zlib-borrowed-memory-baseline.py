import sys,json,tempfile,subprocess,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import build_sdk_package as b
compiler=Path('/home/gavin/code/sindarin/sindarin-rust-method-struct-qualifiers/bin/sn');sdk=(root/'.sn/sdk-native-integration').resolve();report={'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'cases':[]}
with tempfile.TemporaryDirectory(prefix='sn-zlib-baseline-') as folder:
 app=Path(folder);(app/'.sn').mkdir();(app/'.sn/sindarin-pkg-sdk').symlink_to(sdk);(app/'main.sn').write_bytes((sdk/'tests/encoding/test_zlib.sn').read_bytes())
 for target in ('c','rust'):
  cmd=[str(compiler),'main.sn','--no-install','--target',target,'-o',str(app/'client')];c=subprocess.run(cmd,cwd=app,capture_output=True);case={'target':target,'compile_status':c.returncode,'stderr':c.stderr.decode(errors='replace')}
  if not c.returncode:
   r=subprocess.run([str(app/'client')],cwd=app,capture_output=True);case.update(run_status=r.returncode,stdout=r.stdout.decode(errors='replace'),run_stderr=r.stderr.decode(errors='replace'),oracle_agrees=r.stdout==(sdk/'tests/encoding/test_zlib.expected').read_bytes())
  report['cases'].append(case)
 b.SUPPORTED_MODULES+=('encoding/zlib',)
 try:b.prepare(compiler,sdk,app/'package',('encoding/zlib',))
 except Exception as e:report['artifact_error']=str(e)
(root/'.sn/zlib-goal/baseline.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
