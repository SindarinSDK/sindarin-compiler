import gzip, hashlib, json, re, subprocess
from pathlib import Path

root=Path.cwd(); folder=root/'.sn/tcp-artifact-goal'; dest=root/'docs/rust-parity-evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
binary=sha(root/'bin/sn'); assert binary==sha(folder/'final-compiler/sn')
paths={}
def retain(name,path):
    assert path.is_file(),path
    paths[name]=path
for name,count in [('C',3244),('Rust',1099)]:
    p=folder/f'full-{name}.log'; text=re.sub(r'\x1b\[[0-9;]*m','',p.read_text())
    assert 'All tests passed!' in text and sum(map(int,re.findall(r'Results: (\d+) passed, 0 failed',text)))==count
    retain(f'full-{name}.log',p)
composition=read(folder/'composed-validation.json')
assert composition['passed'] and composition['binary_unchanged'] and composition['compiler_sha256']==binary
assert len(composition['checks'])==21 and all(c['status']==0 for c in composition['checks'])
for c in composition['checks']:retain('composed-'+c['name']+'.log',folder/('composed-'+c['name']+'.log'))
for name,count in [('imports',52),('artifacts',22)]:
    assert f'Ran {count} tests' in (folder/('composed-'+name+'.log')).read_text()
assert 'Ran 27 tests' in (folder/'helpers.log').read_text() and '\nOK\n' in (folder/'helpers.log').read_text()
assert 'All files already formatted.' in (folder/'format.log').read_text()
families=[('package-borrowed-scalar-memory',72),('sdk-zlib-artifact',108),
    ('rust-method-struct-parameters',99),('rust-default-array-parameters',45),
    ('package-default-array-parameters',36),('rust-native-array-fields',72),
    ('rust-string-call-arguments',18),('sdk-udp-artifact',108),
    ('sdk-tcp-artifact',144),('record-copy-contract',36)]
for name,count in families:
    for suffix in ('','-sanitized'):
        p=root/'.sn'/(name+suffix+'.json'); d=read(p)
        assert d['passed'] and len(d['cases'])==count,name+suffix
        if 'compiler_sha256' in d:assert d['compiler_sha256']==binary,name+suffix
        if name=='rust-native-array-fields':
            assert all(h==sha(root/'scripts'/script) for script,h in d['scripts_sha256'].items())
        if name=='sdk-udp-artifact':
            assert d['oracle_script_sha256']==sha(root/'scripts/check_sdk_udp_artifact.py')
            assert d['field_controls_script_sha256']==sha(root/'scripts/native_array_field_contexts.py')
            assert 'borrowed-record-parameter-fields' in d['array_field_controls']
        if name=='sdk-tcp-artifact':
            assert d['exports']==25 and d['units']==2 and len(d['contract_rejections'])==16
            assert d['public_sources_preserved'] and d['original_relative_import_preserved'] and d['backing_sources_removed_for_sealed']
            assert all(c['rust_caller'] for c in d['cases'] if c['target']=='rust')
            assert d['oracle_script_sha256']==sha(root/'scripts/check_sdk_tcp_artifact.py')
            assert d['controls_script_sha256']==sha(root/'scripts/tcp_artifact_controls.py')
        retain(p.name,p)
for name,count in [('rust-parity-numeric-places',153),('rust-parity-numeric-native-owners',9)]:
    p=root/'.sn'/(name+'.json'); d=read(p); assert d['passed'] and len(d['cases'])==count and d['compiler_sha256']==binary
    retain(p.name,p)
for phase in ('normal','sanitized'):
    p=folder/f'full-sdk-{phase}.json'; d=read(p)
    assert d['passed'] and len(d['cases'])==864 and len(d['modules'])==22 and len(d['fixtures'])==22
    assert d['compiler_sha256']==binary and d['public_sources_preserved'] and d['backing_sources_removed_for_prebuilt']
    e=read(folder/f'full-sdk-{phase}-execution.json'); assert e['compiler_sha256']==binary
    assert e['oracle_script_sha256']==sha(root/'scripts/check_sdk_artifact.py')
    assert e['builder_script_sha256']==sha(root/'scripts/build_sdk_package.py')
    assert ('sanitize=' in (e['observed_environment']['SN_CFLAGS'] or ''))==(phase=='sanitized')
    for ext in ('.json','.log','-execution.json'):retain(f'full-sdk-{phase}'+ext,folder/(f'full-sdk-{phase}'+ext))
sdk=(root/'.sn/sdk-native-integration').resolve()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=sdk,text=True).strip()=='9d2e6e792746ce22d4ee3e744bc3f9938b59b104'
for name,count in [('tcp-native',21),('tcp-sanitizers',1)]:
    p=sdk/'.sn'/(name+'.json'); d=read(p)
    assert d['passed'] and len(d['cases'])==count and d['compiler_sha256']==binary
    retain('SDK-'+p.name,p)
m=read(folder/'original-corpus/all-mode-discovery.json')
assert len(m['cases'])==12285 and m['compiler_sha256']==binary and m['binary_unchanged'] and m['all_sources_and_oracles_unchanged']
assert sorted(m['counts'].values())==[4,9,1854,10418]
assert all(t['compile']['status']==0 for c in m['cases'] for t in c['targets'].values())
frozen=read(folder/'source-preservation.json')
assert frozen['passed'] and frozen['compiler_sha256']==binary
assert len(frozen['compiler_source_sha256'])==2523 and len(frozen['SDK_source_sha256'])==87
for p,h in frozen['compiler_source_sha256'].items():assert sha(root/p)==h,p
for p,h in frozen['SDK_source_sha256'].items():assert sha(sdk/p)==h,p
regressions=read(folder/'regressions-before-after.json')['cases']; assert len(regressions)==8
for c in regressions:
    if c['version']=='after':
        assert c['compiler_sha256']==binary and c['compile_status']==c['run_status']==0 and c['stdout_hex']==c['expected_stdout_hex'] and not c['stderr_hex']
    elif c['case']=='borrowed-native-field' and c['target']=='rust':assert c['compile_status']!=0 and b'by-value parameter' in bytes.fromhex(c['compile_stderr_hex'])
    elif c['case']=='unused-initializer-effects':assert c['compile_status']==c['run_status']==0 and bytes.fromhex(c['stdout_hex'])==b'false\n'*5
old=json.loads(subprocess.check_output(['git','show','61633bb8:scripts/ci/gates.json'],text=True))
catalog=read(root/'scripts/ci/gates.json'); by={g['id']:g for g in catalog['gates']}
assert len(old['gates'])==234 and all(by[g['id']]==g for g in old['gates'])
assert len(by)==238 and sum(1 if g['linux_only'] else 3 for g in by.values())==540
changed=set(subprocess.check_output(['git','diff','--name-only','61633bb8'],text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
assert not any(p.endswith(('.sn','.expected','.expected.c','.expected.rs')) for p in changed)
for name in ('composed-validation.json','composed-checks.json','validate-composed.py','composed-driver.log',
    'helpers.log','format.log','audit-original-modes-final.py','original-modes.log','source-preservation.json',
    'regressions-before-after.json','reference-field-before.json','reference-field-before.log',
    'legacy-field-copy.json','legacy-field-copy.py','legacy-field-copy.log',
    'focused-first-timeout.log','before-optimizer-focused-normal.log',
    'api-O1-hang.sn.raw','api-O1-generated-after.c','api-O1-generated-after.json',
    'native-normal.log','native-sanitized.log','observe-sdk-environment.py','retain-local.py'):
    retain(name,folder/name)
retain('original-corpus.json',folder/'original-corpus/all-mode-discovery.json')
retain('api-O1-generated-before.c',folder/'api-O1-generated/control_3633338/main.c')
for name in ('borrowed-field-overlap.json','borrowed-field-legacy.json','borrowed-field-legacy-rust.json',
             'managed-overlap-checks.json','managed-overlap-validation.json','managed-overlap-driver.log',
             'validate-managed-overlap.py'):
    retain(name,folder/name)
retained=[]
for name,p in paths.items():
    out=dest/('tcp-artifact-'+name+'.gz');out.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    retained.append(dict(path=out.relative_to(root).as_posix(),sha256=sha(out),raw_sha256=sha(p)))
proof=dict(status='Complete local TCP/SDK22 integration; own integrated hosted acceptance remains required.',
    base='61633bb80d15bc0df80b4aee2d86ac2bbe75082e',SDK_revision='9d2e6e792746ce22d4ee3e744bc3f9938b59b104',
    compiler_sha256=binary,full_C=3244,full_Rust=1099,composed_commands=21,
    source_and_script_sha256={p:sha(root/p) for p in sorted(changed) if not p.startswith('docs/')},
    SDK_modules=22,SDK_C_Sindarin_units=44,SDK_cases_each_environment=864,
    TCP_artifact_cases_each_environment=144,TCP_exports=25,TCP_artifact_units=2,
    TCP_separate_copy_contract_rejections_each_environment=16,TCP_native_cases=21,TCP_actual_C_runtime_SAN_cases=1,
    CI_helpers=27,gate_definitions=238,platform_executions=540,platform_groups=41,all_234_prior_gates_unchanged=True,
    fresh_original_sources=1365,fresh_original_mode_cases=12285,fresh_successful_C_and_Rust_compilations=24570,
    mode_classifications=m['counts'],known_C_undefined_modes_not_credited=13,
    source_preservation=dict(compiler_sources_and_oracles_unchanged=2523,SDK_sources_and_oracles_unchanged=87,SDK_public_modules_unchanged=28),
    repairs=['Borrowed canonical native record parameter field stores use shared setters and preserve caller aliases.',
             'Unused static/method/nested initializer calls retain effects and cleanup; established scalar arithmetic elision is preserved.'],
    scope='Unchanged TCP API, original relative imports, independent source/sealed C artifacts, verified Rust caller bodies, all25exports, aliases/fields, scoped socket cleanup, escaped binary bytes/UTF8 strings/address results, nil/default records, timeout/EOF and shutdown. TCP copies are unsupported by legacy C too; matching rejection receives no parity credit. Remaining SDK modules core/fields,core/version,net/tls,net/dtls,net/ssh,net/git, broader ownership/interface/generic/callback/dependency-lifecycle contracts and final integrated platform/corpus acceptance remain open. Four legacy C debug lifetime leaks and a historical unadjudicated TLS failure remain open; fresh passing controls do not erase those findings.',
    retained_reports=retained)
(dest/'tcp-artifact-local-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print('Retained complete local TCP/SDK22 proof:',len(retained),'reports')
