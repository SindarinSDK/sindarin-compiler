import concurrent.futures,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();folder=root/'.sn/zlib-goal/CI-failure-40206567956';compiler=root/'bin/sn'
san={'SN_CC':'gcc','SN_CFLAGS':'-fsanitize=address,undefined -fno-omit-frame-pointer','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
report={'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'started':time.time(),'checks':[]}
def run(check):
 name,cmd,extra=check;print('START',name,flush=True);start=time.monotonic()
 with (folder/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,env={**os.environ,**extra},stdout=log,stderr=subprocess.STDOUT)
 result={'name':name,'command':list(map(str,cmd)),'environment':extra,'status':r.returncode,'seconds':time.monotonic()-start};print('END',name,r.returncode,flush=True);return result
def retain():
 report['passed']=all(c['status']==0 for c in report['checks']);(folder/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
for name,cmd in [('full-C',['python3','scripts/run_tests.py','all','--verbose','-j','8']),('full-Rust',['python3','scripts/run_rust_tests.py','all','--verbose','-j','8'])]:
 report['checks'].append(run((name,cmd,{})));retain()
 if not report['passed']:raise SystemExit(1)
audit=folder/'audit-original-modes.py';source=(root/'.sn/zlib-goal/audit-original-modes-final.py').read_text().replace("compiler=root/'.sn/zlib-goal/loan-compiler/sn'","compiler=root/'bin/sn'").replace("folder=root/'.sn/zlib-goal/original-corpus-final'","folder=root/'.sn/zlib-goal/CI-failure-40206567956/original-corpus'");audit.write_text(source)
audit_log=(folder/'original-modes.log').open('wb');process=subprocess.Popen(['python3',str(audit)],cwd=root,stdout=audit_log,stderr=subprocess.STDOUT);(folder/'original-audit-process.json').write_text(json.dumps({'pid':process.pid,'script':str(audit)}))
checks=[]
for name,script in [('zlib','scripts/check_sdk_zlib_artifact.py'),('integer','scripts/check_rust_integer_match_patterns.py'),('integer-package','tests/package/integer_match_patterns.py'),('memory','tests/package/borrowed_scalar_memory.py'),('array-loans','scripts/check_c_array_call_arguments.py')]:
 for suffix,env in [('normal',{}),('sanitized',san)]:checks.append((name+'-'+suffix,['python3',script],env))
checks += [('PID-capture',['python3','tests/package/integer_match_capture.py'],{}),('imports',['python3','tests/package/native_imports.py'],{}),('artifacts',['python3','tests/package/native_artifacts.py'],{}),('helpers',['python3','-m','unittest','discover','-s','tests/ci','-v'],{}),('format',[compiler,'--format','--check'],{})]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,c) for c in checks]):report['checks'].append(future.result());retain()
for name,extra in [('SDK21-normal',{}),('SDK21-sanitized',san)]:
 result=run((name,['python3','scripts/check_sdk_artifact.py'],extra));report['checks'].append(result)
 if result['status']==0:(folder/(name+'.json')).write_bytes((root/'.sn/sdk-artifact-validation.json').read_bytes())
 retain()
process.wait();audit_log.close();report['original_audit_status']=process.returncode;report['finished']=time.time();report['binary_unchanged']=hashlib.sha256(compiler.read_bytes()).hexdigest()==report['compiler_sha256'];retain()
assert report['passed'] and process.returncode==0 and report['binary_unchanged']
