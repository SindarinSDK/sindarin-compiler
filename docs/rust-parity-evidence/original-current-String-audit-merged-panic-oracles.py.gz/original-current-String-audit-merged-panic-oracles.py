import hashlib,json,subprocess,tempfile
from pathlib import Path
root=Path.cwd();folder=root/'.sn/string-call-owners-goal/original-corpus';source=root/'tests/integration/test_assert.sn';expected=source.with_suffix('.expected').read_bytes();r={'source':str(source.relative_to(root)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(expected).hexdigest(),'compiler_sha256':hashlib.sha256((root/'bin/sn').read_bytes()).hexdigest(),'cases':[],'reason':'Initial all-mode discovery captured stdout/stderr separately then concatenated for oracle comparison. That loses actual interleaving when panic writes stderr before exit flushes stdout. Preserve raw run and verify original oracle with real merged descriptor, matching original harness; no program/oracle/backend change.'}
with tempfile.TemporaryDirectory(prefix='sn-original-merged-oracles-') as tmp:
 for opt in ['-O0','-O1','-O2']:
  for mode in ['default','checked','unchecked']:
   for target in ['c','rust']:
    exe=Path(tmp)/source.stem;cmd=[root/'bin/sn',source,'--no-install','--target',target,opt,'-o',exe]
    if mode!='default':cmd.append('--'+mode)
    p=subprocess.run([str(x) for x in cmd],cwd=root,capture_output=True,timeout=120);case={'opt':opt,'mode':mode,'target':target,'compile':{'status':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()}}
    if p.returncode==0:
     q=subprocess.run([str(exe)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10);case['run']={'status':q.returncode,'merged_output_hex':q.stdout.hex()};case['passed']=q.returncode!=0 and q.stdout==expected
    r['cases'].append(case);print(opt,mode,target,case.get('passed',False),flush=True)
r['passed']=len(r['cases'])==18 and all(c.get('passed') for c in r['cases']);(folder/'actual-merged-panic-oracles.json').write_text(json.dumps(r,indent=2)+'\n')
