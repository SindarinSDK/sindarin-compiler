from pathlib import Path
import tempfile,subprocess,os,json,hashlib
root=Path.cwd();compiler=Path('/home/gavin/code/sindarin/sindarin-rust-method-struct-qualifiers/bin/sn');sdk=(root/'.sn/sdk-native-integration').resolve();env={**os.environ,'SN_CC':'gcc','SN_CFLAGS':'-fsanitize=address,undefined -fno-omit-frame-pointer','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
with tempfile.TemporaryDirectory(prefix='sn-zlib-C-baseline-SAN-') as f:
 app=Path(f);(app/'.sn').mkdir();(app/'.sn/sindarin-pkg-sdk').symlink_to(sdk);(app/'main.sn').write_bytes((sdk/'tests/encoding/test_zlib.sn').read_bytes())
 c=subprocess.run([str(compiler),'main.sn','--no-install','--target','c','-o',str(app/'client')],cwd=app,env=env,capture_output=True)
 r={'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'compile_status':c.returncode,'compile_stderr':c.stderr.decode(errors='replace')}
 if not c.returncode:
  v=subprocess.run([str(app/'client')],cwd=app,env=env,capture_output=True);r.update(run_status=v.returncode,stdout=v.stdout.decode(errors='replace'),stderr=v.stderr.decode(errors='replace'))
(root/'.sn/zlib-goal/accepted-method-C-leak.json').write_text(json.dumps(r,indent=2)+'\n');print(r.get('run_status'),r.get('stderr','')[-180:])
